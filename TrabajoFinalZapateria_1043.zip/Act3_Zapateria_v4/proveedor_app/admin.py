from django.contrib import admin
from .models import Proveedor

# Register your models here.

admin.site.register(Proveedor)